# Copyright (c) 2022-2025, The Isaac Lab Project Developers (https://github.com/isaac-sim/IsaacLab/blob/main/CONTRIBUTORS.md).
# All rights reserved.
#
# SPDX-License-Identifier: BSD-3-Clause

"""Classic environments for control.

These environments are based on the MuJoCo environments provided by OpenAI.

Reference:
    https://github.com/openai/gym/tree/master/gym/envs/mujoco
"""
